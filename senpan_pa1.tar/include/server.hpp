#ifndef SERVER_HPP
#define SERVER_HPP

int server(int port);

#endif